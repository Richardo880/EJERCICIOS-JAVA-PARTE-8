/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package E4;

/**
 *
 * @author diego
 */
public class ErrorDeCadenaLongitud extends ErrorDeCadena{

    public ErrorDeCadenaLongitud() {
        super("La cadena tiene mas de 30 caracteres");
    }
    
}
