/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package E4;

/**
 *
 * @author diego
 */
public class ErrorDeCadenaCaracteres extends ErrorDeCadena{

    public ErrorDeCadenaCaracteres() {
        super("La cadena tiene caracteres no alfabeticos");
    }
    
}
