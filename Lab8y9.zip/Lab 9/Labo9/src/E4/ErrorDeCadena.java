package E4;

public class ErrorDeCadena extends Exception{

    public ErrorDeCadena() {
    }

    public ErrorDeCadena(String mensaje) {
        super(mensaje);
    }    
}
